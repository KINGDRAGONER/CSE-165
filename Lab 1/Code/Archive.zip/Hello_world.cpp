#include <iostream>

using namespace std;

int main()
{
	cout << "Hi, my name is Munir!" << endl;
	
	return 0;
}
